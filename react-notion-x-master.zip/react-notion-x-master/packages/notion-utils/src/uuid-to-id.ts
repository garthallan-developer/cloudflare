export const uuidToId = (uuid: string) => uuid.replace(/-/g, '')
